# SPICE Educational Agent Skills

Paquete académico de 10 skills para un Custom Agent educativo de simulación de circuitos.

## Orden recomendado de lectura

1. engineering-units-and-conventions
2. spice-netlist-fundamentals
3. circuit-graph-theory
4. incidence-matrix-method
5. component-constitutive-models
6. classical-nodal-analysis
7. tableau-formulation
8. ac-frequency-analysis
9. solver-validation
10. explainable-circuit-reporting

Cada carpeta contiene un archivo `SKILL.md`. Los skills especifican conocimiento y metodología; los cálculos deben ejecutarse mediante tools deterministas en Python.
